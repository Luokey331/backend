var express = require('express');
var router = express.Router();


router.get('/', function(req, res, next) {

      var data = { 
        FirstName: 'pikachu', 
        LastName: 'mega punch', 
        MiddleName: 'electric',
        Emailaddress: 'user@sample.com',
        Mobilenumber: '17924152773',
        county: '+86',
        roles:'common' 
      };
      var useruniq_id = Date.now();
      test_db.insert(data, 'user_'+ useruniq_id, function(err, body){
      if(!err){
        res.send( body.id + ' resgisted');
        console.log(body);
      }
      });
    
  });

  test_db.update = function(obj, key, callback){
    var db = this;
    db.get(key, function(error, existing){
      if(!error) obj._rev = existing._rev;
      db.insert(obj, key, callback);
    });
  }
  module.exports = router;