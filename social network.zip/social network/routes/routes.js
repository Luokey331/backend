module.exports = function(){
    var indexRouter = function(req, res, next){
        res.render('index', { title: 'Express' });
    }
    var usersRouter = function(req, res, next){
        res.send('respond with a resource');
    }
    var registerRouter = function(req, res, next){
        var data = { 
            FirstName: 'pikachu', 
            LastName: 'mega punch', 
            MiddleName: 'electric',
            Emailaddress: 'user@sample.com',
            Mobilenumber: '17924152773',
            county: '+86',
            roles:'common' 
          };
          var useruniq_id = Date.now();
          test_db.insert(data, 'user_'+ useruniq_id, function(err, body){
          if(!err){
            res.send( body.id + ' resgisted');
            console.log(body);
          }
          });
    }
    app.get('/', indexRouter);
    app.get('/users', usersRouter);
    app.get('/register', registerRouter);
}



